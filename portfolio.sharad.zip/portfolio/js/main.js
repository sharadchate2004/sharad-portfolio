(() => {
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];

  $('#year').textContent = new Date().getFullYear();

  // Sticky nav shadow + active link highlight
  const nav = $('#nav');
  const links = $$('#navLinks a');
  const sections = links.map(a => $(a.getAttribute('href'))).filter(Boolean);
  const onScroll = () => {
    nav.classList.toggle('scrolled', window.scrollY > 10);
    const y = window.scrollY + 120;
    let current = sections[0];
    sections.forEach(s => { if (s.offsetTop <= y) current = s; });
    links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + current.id));
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // Mobile menu
  const toggle = $('#navToggle'), menu = $('#navLinks');
  toggle.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
  });
  links.forEach(a => a.addEventListener('click', () => {
    menu.classList.remove('open'); toggle.setAttribute('aria-expanded', false);
  }));

  // Scroll reveal
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); } });
  }, { threshold: 0.12 });
  $$('.reveal').forEach(el => io.observe(el));

  // Project image slider
  const slider = $('#slider');
  if (slider) {
    const imgs = $$('img', slider);
    let i = 0, timer;
    const show = n => { imgs[i].classList.remove('active'); i = (n + imgs.length) % imgs.length; imgs[i].classList.add('active'); };
    const auto = () => { clearInterval(timer); timer = setInterval(() => show(i + 1), 4500); };
    $('.next', slider).addEventListener('click', () => { show(i + 1); auto(); });
    $('.prev', slider).addEventListener('click', () => { show(i - 1); auto(); });
    auto();
  }

  // Contact form: validates, then opens the visitor's email app (no backend needed).
  const RECEIVER = 'you@example.com'; // <-- change to your email
  const form = $('#contactForm'), note = $('#formNote');
  form.addEventListener('submit', e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(form));
    let ok = true;
    $$('input,textarea', form).forEach(f => {
      const bad = !f.value.trim() || (f.type === 'email' && !/^\S+@\S+\.\S+$/.test(f.value));
      f.classList.toggle('invalid', bad); if (bad) ok = false;
    });
    note.classList.toggle('err', !ok);
    if (!ok) { note.textContent = 'Please fill in every field with valid details.'; return; }
    const body = `${d.message}\n\n— ${d.name} (${d.email})`;
    window.location.href = `mailto:${RECEIVER}?subject=${encodeURIComponent('Portfolio message from ' + d.name)}&body=${encodeURIComponent(body)}`;
    note.textContent = 'Thanks! Your email app should open with the message ready to send.';
    form.reset();
  });
})();
